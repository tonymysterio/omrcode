

//update 

//var _ps = new _processSettings();
//var _ss = new _serviceStatus();


function updateServiceStatuses() {

    //#serviceStatus
    /*Object.keys(obj).forEach(function(key) {
        console.log(key, obj[key]);
    });*/

    

    /*var myNode = document.getElementById("serviceStatus");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
    }*/

    Object.keys(_ss.statusHistory).forEach(function(key) {
        console.log(key, _ss.statusHistory[key]);
        var yNode = document.getElementById(key);
        console.log(yNode);
        let tw = timeConverter(_ss.statusHistory[key].timestamp)
        yNode.innerHTML = tw;
    });


}

function requestDaily () {

    alert("requestDaily")

}

function requestRealtime () {

    alert("requestRealtime")

}


updateServiceStatuses();

