var _processSettings = function(){

    this.mailRecipients = {
     "0" : {email : "zestdaily1@test.com" , "type" : "daily" ,  "timestamp" : 12341324},
     "1" : {email : "testreal1@test.com" , "type" : "realtime","timestamp" : 12341324 },
     "2" : {email : "testAdmin1@test.com" , "type" : "admin" ,"timestamp" : 12341324},
     "3" : {email : "realtime2@test.com" , "type" : "realtime","timestamp" : 12341324 },
     "4" : {email : "daily2@test.com" , "type" : "daily","timestamp" : 12341324 },

    }


}

var _serviceStatus = function(){

    this.statusHistory = {

        "dailyReportLastRun" : { "timestamp" : 12341324},
        "realtimeReportLastRun" : { "timestamp" : 12341524 },
        "errorLogUpdated" : { "timestamp" : 12344324 }
    }



}

var _ps = new _processSettings();
var _ss = new _serviceStatus();


function timeConverter(UNIX_timestamp){
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
    return time;
  }

  