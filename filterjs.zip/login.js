//import { el } from 'redom';
const { el, mount } = redom;

// define Login component
class Login {
  constructor () {
    this.el = el('form#login',
      this.email = el('input.email', { type: 'email' }),
      this.pass = el('input.pass', { type: 'password' }),
      this.submit = el('button', { type: 'submit' },
        'Sign in'
      )
    );
    this.el.onsubmit = e => {
      e.preventDefault();

      const email = this.email.value;
      const pass = this.pass.value;

      console.log(email, pass);
    };
  }
}

let _l = new Login();

function login (){

    //e.preventDefault();
    let email = document.getElementById('email');
    let pw = document.getElementById('password');

    console.log(email.value + ' ' + pw.value);

}