const { el, mount ,setChildren, setAttr } = redom;
//update 

//var _ps = new _processSettings();
//var _ss = new _serviceStatus();


/*
var t2 = el('label',{
    //value : "realtime",
    for : parentName,
    innerHTML : parentName,
    type : 'label',
})

rowPre.appendChild(t2);
rowPre.appendChild(t);
rowPre.appendChild(row);
*/




var _ps = new _processSettings();


function rowItem (rowData){

    var l = [];

    var row = el('tr',{
        
    })

    Object.keys(rowData).forEach(function(key) {
        
        let vv = rowData[key];
        let ch = el('td',{
            innerHTML : vv
        })

        row.appendChild(ch);

    })

    return row;

}


function displayTable (data) {

    //data contains filter and list

    var yNode = document.getElementById('reportTable');

    //make table headers

    let thead = el('thead',{
        innerHTML : ''
    })

    let headers = el('tr',{
        innerHTML : ''
    })



    Object.keys(data.list[0]).forEach(function(key) {

        let ch = el('th',{
            innerHTML : key
        })

        headers.appendChild(ch);
    })

    thead.appendChild(headers);
    yNode.appendChild(thead);

    //Object.keys(data.list).forEach(function(key) {
    let tbody = el('tbody',{
            innerHTML : ''
        })

    while (a=data.list.pop()){ 

        /*var row = el('label',{
            //value : "realtime",
            for : parentName,
            innerHTML : parentName,
            type : 'label',
        })*/

        var row = rowItem(a);

        tbody.appendChild(row);

        

    }

    yNode.appendChild(tbody);

    //add sorting
    new Tablesort(document.getElementById('reportTable'));

}


var request = new XMLHttpRequest();
request.open('GET', '/filteredQuery', true);

request.onload = function() {
  if (request.status >= 200 && request.status < 400) {
    // Success!
    var data = JSON.parse(request.responseText);
    displayTable(data);

  } else {
    // We reached our target server, but it returned an error

  }
};

request.onerror = function() {
  // There was a connection error of some sort
};

request.send();
