
const { el, mount ,setChildren, setAttr } = redom;
//update 

//var _ps = new _processSettings();
//var _ss = new _serviceStatus();

var _ps = new _processSettings();


function recipientEntry (o,key) {

    let email = o.email;
    let rtype = o.type;

    let s = el('input', { type: 'email', autofocus: false, value: email })
    /*let drp  = el('select#redom-logo.logo', {
        
        
      },el('option#',{
          value : "realtime",
          text : "realtime"
      }),el('option#tst',{
        value : "daily",
        text : "daily"
      }),el('option#tst',{
        value : "systemStatus",
        text : "system status"
    })


    );*/
    var lacoNo = 'sel_'+key;
    //const lxco = el('.row',  el ('.six columns',
    const lxco = el ('.six columns',
         el('label.label',{
            //value : "realtime",
            for : lacoNo+"_e",
            innerHTML : "email adress"
        }),
        el('input#'+lacoNo+"_e", { type: 'email', autofocus: false, value: email })
        );


    const laco =   el ('.six columns',
        el('label.label',{
            //value : "realtime",
            for : lacoNo,
            innerHTML : "report type to recieve"
        }),el('select#'+lacoNo+'.u-full-width', {
            },el('option#',{
            value : "realtime",
            text : "realtime"
            }),el('option#',{
          value : "daily",
          text : "daily"
            }),el('option#',{
          value : "admin",
          text : "system status"
        })
    ));
    
    const row = el('.row');

    var yNode = document.getElementById('listForm');
    yNode.insertBefore(row, yNode.firstChild);

    row.insertBefore(laco, row.firstChild);
    row.insertBefore(lxco, row.firstChild);
    var t = document.getElementById(lacoNo).value = o.type;
    var td = document.getElementById(lacoNo+"_e").value = o.email;
    
    return;

}

function updateProcessSettings() {

    //#serviceStatus
    /*Object.keys(obj).forEach(function(key) {
        console.log(key, obj[key]);
    });*/

    

    /*var myNode = document.getElementById("serviceStatus");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.firstChild);
    }*/
    var yNode = document.getElementById('formList');

    Object.keys(_ps.mailRecipients).forEach(function(key) {
        console.log(key, _ps.mailRecipients[key]);

        var nb = recipientEntry(_ps.mailRecipients[key],key);
        /*
        var yNode = document.getElementById(key);
        console.log(yNode);
        let tw = timeConverter(_ss.statusHistory[key].timestamp)
        yNode.innerHTML = tw;*/
    });


}

updateProcessSettings();


function addRecipient () {

    var nb = recipientEntry({email:"",type:"daily"},false);

    alert("addRecipient")

}

function requestRealtime () {

    alert("requestRealtime")

}


updateServiceStatuses();

